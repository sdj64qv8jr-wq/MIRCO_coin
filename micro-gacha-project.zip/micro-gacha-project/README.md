# $MICRO GACHA 🎰

$MICROトークンのバーン型ガチャシステム

## Features
- 🎴 全10種カード（SECRET / SSR / R / N）
- 💥 オリパ風演出（ブラックアウト→プチュン→画面ヒビ割れ）
- 🎯 天井システム（50回でSSR確定）
- 📖 コレクション図鑑
- 📸 X(Twitter)シェア画像自動生成
- 🔊 サウンドエフェクト
- 🎴 3Dカードティルトエフェクト

## Setup

```bash
npm install
npm run dev
```

## Deploy

### Vercel（おすすめ）
1. GitHubにpush
2. [vercel.com](https://vercel.com) でImport
3. そのままDeploy

### GitHub Pages
```bash
npm run build
```
`dist` フォルダをデプロイ

## Tech Stack
- React 18
- Vite
- Web Audio API
- Canvas API
