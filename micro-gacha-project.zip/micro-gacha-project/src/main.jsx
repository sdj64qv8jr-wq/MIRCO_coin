import React from 'react'
import ReactDOM from 'react-dom/client'
import MicroGacha from './MicroGacha.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <MicroGacha />
  </React.StrictMode>,
)
